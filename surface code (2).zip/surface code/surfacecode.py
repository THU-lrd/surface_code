import numpy as np
import copy
import stim
# from matplotlib import pyplot as plt
from stim import Circuit

s = stim.TableauSimulator()

num_measure = 0
num_data = 1
width = 1
length = 1
gap = 1


def init(num_m: int, num_d: int, wide: int, len: int):
    global num_measure
    global num_data
    global width
    global length
    global gap
    num_measure = num_m
    num_data = num_d
    width = wide
    length = len
    gap = width - 1 + width
    return


def MX(circ: Circuit, qdict: list, index: int):
    circ.append("H", [index])
    for i in range(1, len(qdict[index - num_data])):
        circ.append("CNOT", [index, qdict[index - num_data][i]])
    circ.append("H", [index])
    circ.append("M", [index])
    return circ


def MZ(circ: Circuit, qdict: list, index: int):
    for i in range(1, len(qdict[index - num_data])):
        circ.append("CNOT", [qdict[index - num_data][i], index])
    circ.append("M", [index])
    return circ


def runcirc(qdict: np.array):
    circ = stim.Circuit()
    for i in range(0, len(qdict)):
        if qdic[i][0] == -1:
            circ = MX(circ, qdict, i + num_data)
        else:
            circ = MZ(circ, qdict, i + num_data)
    return circ


def measure_result(circ: Circuit):
    s.do(circ)
    print('调用s.do')
    # print(len(s.current_measurement_record()))
    for i in range(0, num_measure):
        s.reset(i + num_data)
    tmp = copy.deepcopy(s.current_measurement_record())
    record_tmp = np.array(list(map(int, tmp)))
    for k in range(0, len(record_tmp)):
        record_tmp[k] = 2 * (record_tmp[k] - 1 / 2)
    record_tmp = list(record_tmp)
    return record_tmp


def get_record(circ: Circuit):
    global record
    global measure_total
    tmp_result1 = measure_result(circ)
    tmp1 = copy.deepcopy(tmp_result1)
    measure_total.append(tmp1)

    if len(measure_total) == 1:
        current_total = tmp1[0:  len(measure_total[-1])]
    else:
        # print("len(measure_total[-2]) = ", len(measure_total[-2]))
        # print("len(measure_total[-3]) = ", len(measure_total[-3]))
        # print("len(measure_total[-1]) = ", len(measure_total[-1]))
        current_total = tmp1[len(measure_total[-2]):]
    # print("len(current_total) = ", len(current_total))
    # print("len(measure_total) = ", len(measure_total))
    record.append(current_total)
    return record


def turn_off(remove_list: list):
    global qdic
    for i in remove_list:
        for j in qdic:
            if i in j:
                j.remove(i)
            else:
                pass
    return qdic


def turn_on(append_list: list):
    for i in append_list:
        for j in range(0, len(qdic_const)):
            if i in qdic_const[j]:
                qdic[j].append(i)
            else:
                pass
    return qdic


# circuit = stim.Circuit()

# init(97, 98, 7, 8)
# init(7, 8, 3, 2)
# qdic元素中[-1, *, *, *]表示X-measure qubit作用的data qubit, [-2, *, *, *]表示Z-measure qubit作用的data qubit

qdic = []
qdic_const = []


def get_qdic(xbound=True):
    global qdic
    global qdic_const
    if xbound:
        for i in range(0, width - 1):
            tmp = [-1, i, i + 1, i + width]
            qdic.append(tmp)
        for i in range(width - 1, num_measure - (width - 1)):
            if (i - (width - 1)) % gap == 0:
                tmp = [-2, i - (width - 1), i + 1, i + width]
                qdic.append(tmp)
            elif (i - 2 * (width - 1)) % gap == 0:
                tmp = [-2, i - (width - 1), i, i + width]
                qdic.append(tmp)
            else:
                if i % gap >= width - 1:
                    tmp = [-2, i - (width - 1), i, i + 1, i + width]
                    qdic.append(tmp)
                else:
                    tmp = [-1, i - (width - 1), i, i + 1, i + width]
                    qdic.append(tmp)
        for i in range(num_measure - (width - 1), num_measure):
            tmp = [-1, i - (width - 1), i, i + 1]
            qdic.append(tmp)
    else:
        for i in range(0, width - 1):
            tmp = [-2, i, i + 1, i + width]
            qdic.append(tmp)
        for i in range(width - 1, num_measure - (width - 1)):
            if (i - (width - 1)) % gap == 0:
                tmp = [-1, i - (width - 1), i + 1, i + width]
                qdic.append(tmp)
            elif (i - 2 * (width - 1)) % gap == 0:
                tmp = [-1, i - (width - 1), i, i + width]
                qdic.append(tmp)
            else:
                if i % gap >= width - 1:
                    tmp = [-1, i - (width - 1), i, i + 1, i + width]
                    qdic.append(tmp)
                else:
                    tmp = [-2, i - (width - 1), i, i + 1, i + width]
                    qdic.append(tmp)
        for i in range(num_measure - (width - 1), num_measure):
            tmp = [-2, i - (width - 1), i, i + 1]
            qdic.append(tmp)
    qdic_const = copy.deepcopy(qdic)
    return qdic


record = []
measure_total = []

"""byproduct_err非空时，其元素为长度为 3 的列表[a, b, c]，a代表发生x or z 错误的比特位置，
b = 0 代表错误类型为x， b = 1 代表错误类型为z， c代表发生错误的时间（c代表的是该错误发生在第c次测量和第c + 1次测量之间）"""
byproduct_err = []


# 以下每个逻辑门操作开始前都要get record，以便记录最新的error syndrome
def cut(turn_off_1: int, turn_off_2: int,
        scale: int, x_cut=True):
    global qdic
    global record
    label = np.array([])  # 记录的是包含于cut里面的除了最外层的measure qubit的index
    label0 = np.array([])  # 记录的是包含于cut里面的最外层的measure qubit的index
    isolate = []  # 记录的是包含于cut里面的最外层的data qubit的index(cut中的孤立数据比特的index，存储在isolate中)

    for k in range(0, scale - 1):
        for j in range(0, k):
            label = np.append(label, [turn_off_1 - width * k + j, turn_off_1 - (width - 1) * k + gap * j,
                                      turn_off_1 + width * k - j, turn_off_1 + (width - 1) * k - gap * j,
                                      turn_off_2 - width * k + j, turn_off_2 - (width - 1) * k + gap * j,
                                      turn_off_2 + width * k - j, turn_off_2 + (width - 1) * k - gap * j])
    label = [int(item) for item in label]

    k = (scale - 1)
    j = 0
    while j < k:
        label0 = np.append(label0, [turn_off_1 - width * k + j, turn_off_1 - (width - 1) * k + gap * j,
                                    turn_off_1 + width * k - j, turn_off_1 + (width - 1) * k - gap * j,
                                    turn_off_2 - width * k + j, turn_off_2 - (width - 1) * k + gap * j,
                                    turn_off_2 + width * k - j, turn_off_2 + (width - 1) * k - gap * j])
        j += 1
    label0 = [int(item) for item in label0]
    label0.append(turn_off_1)
    label0.append(turn_off_2)

    for j in list(label0):
        qdic[j - num_data] = [qdic[j - num_data][0]]
    for j in list(label):
        for k in qdic[j - num_data][1:]:
            isolate.append(k)
    # 更新字典
    qdic = turn_off(isolate)
    circuit = runcirc(qdic)
    circuit_tmp = circuit.copy()

    to_mea = np.array([])

    j = 0
    while j < scale - 1:
        to_mea = np.append(to_mea, [turn_off_1 - width * scale - num_data + 1 + j,
                                    turn_off_1 - (width - 1) * scale - num_data + width + gap * j,
                                    turn_off_1 + width * scale - num_data - j,
                                    turn_off_1 + (width - 1) * scale - num_data - (width - 1) - gap * j,
                                    turn_off_2 - width * scale - num_data + 1 + j,
                                    turn_off_2 - (width - 1) * scale - num_data + width + gap * j,
                                    turn_off_2 + width * scale - num_data - j,
                                    turn_off_2 + (width - 1) * scale - num_data - (width - 1) - gap * j])
        j += 1
        to_mea = [int(item) for item in to_mea]

    for k in to_mea:
        if x_cut:
            circuit_tmp.append("M", k)
        else:
            circuit_tmp.append("MX", k)
    record = get_record(circuit_tmp)
    j = 1
    while j < scale:
        record[-1][turn_off_1 - width * scale + j - num_data] *= record[-1][num_measure + 8 * (j - 1) - 1]
        record[-1][turn_off_1 - (width - 1) * scale + gap * j - num_data] *= record[-1][
            num_measure + 8 * (j - 1) + 1 - 1]
        record[-1][turn_off_1 + width * scale - j - num_data] *= record[-1][num_measure + 8 * (j - 1) + 2 - 1]
        record[-1][turn_off_1 + (width - 1) * scale - gap * j - num_data] *= record[-1][
            num_measure + 8 * (j - 1) + 3 - 1]
        record[-1][turn_off_2 - width * scale + j - num_data] *= record[-1][num_measure + 8 * (j - 1) + 4 - 1]
        record[-1][turn_off_2 - (width - 1) * scale + gap * j - num_data] *= record[-1][
            num_measure + 8 * (j - 1) + 5 - 1]
        record[-1][turn_off_2 + width * scale - j - num_data] *= record[-1][num_measure + 8 * (j - 1) + 6 - 1]
        record[-1][turn_off_2 + (width - 1) * scale - gap * j - num_data] *= record[-1][
            num_measure + 8 * (j - 1) + 7 - 1]
        j += 1
    circuit_tmp.clear()
    record[-1] = record[-1][0: num_measure]
    return circuit, qdic, record


def apply_cut(scale: int, turn_off_1: int, turn_off_2: int,
              square_X=True):
    """this function can only be used after the surface code has cut holes, and the parameter: turn_off_1 <
     turn_off_2 is the index of the measure qubits in the center of the two holes"""
    global qdic
    global record
    if square_X:
        def apply_xl(circuit: Circuit):
            X_L = np.array([])
            for k in range(0, scale):
                X_L = np.append(X_L,
                                [turn_off_2 - num_data + 1 - width * scale + k, turn_off_2 - num_data
                                 + width - (width - 1) * scale + k * gap, turn_off_2 - num_data + width * scale - k,
                                 turn_off_2 - num_data - (width - 1) + (width - 1) * scale - gap * k])
                X_L = [int(item) for item in X_L]
            for k in X_L:
                circuit.append("X", k)
            return circuit

        def apply_zl(circuit: Circuit):
            Z_L = np.array([])
            j = turn_off_1 + (width - 1) * scale - num_data + 1
            while j <= turn_off_2 - width * scale - num_data + 1:
                Z_L = np.append(Z_L, j)
                j += gap
            Z_L = [int(item) for item in Z_L]
            for k in Z_L:
                circuit.append("Z", k)
            return circuit

    else:
        def apply_zl(circuit: Circuit):
            Z_L = np.array([])
            for k in range(0, scale):
                Z_L = np.append(Z_L,
                                [turn_off_2 - width * scale - num_data + 1 + k,
                                 turn_off_2 - (width - 1) * scale - num_data + width + k * gap,
                                 turn_off_2 + width * scale - num_data - k,
                                 turn_off_2 + (width - 1) * scale - num_data - (width - 1) - gap * k])
            Z_L = [int(item) for item in Z_L]
            for k in Z_L:
                circuit.append("Z", k)
            return circuit

        def apply_xl(circuit: Circuit):
            X_L = np.array([])
            j = turn_off_1 + (width - 1) * scale - num_data + 1
            while j <= turn_off_2 - width * scale - num_data + 1:
                X_L = np.append(X_L, j)
                j += gap
            X_L = [int(item) for item in X_L]
            for j in X_L:
                circuit.append("X", j)
            return circuit

    return apply_xl, apply_zl


def cut_init(scale: int, turn_off1: int, turn_off2: int, difficult=True, xcut=True):
    global qdic
    global record

    if difficult:

        # 更新字典
        i = turn_off1
        while i < turn_off2:
            qdic[i - num_data] = [qdic[i - num_data][0]]
            qdic[i - num_data + (width - 1)].remove(i - num_data + width)
            # print('i - num_data + width', i - num_data + width)
            # print('qdic[i - num_data + width]', qdic[i - num_data + width])
            qdic[i - num_data + width].remove(i - num_data + width)
            i += gap
        qdic[turn_off2 - num_data] = [qdic[turn_off2 - num_data][0]]
        # 更新电路
        circuit = runcirc(qdic)

        # error track
        circuit_tmp = circuit.copy()
        j = turn_off1 - num_data + width
        while j <= turn_off2 - num_data - (width - 1):
            if xcut:
                circuit_tmp.append("M", j)
            else:
                circuit_tmp.append("MX", j)
            j += gap
        record = get_record(circuit_tmp)
        j = turn_off1 - num_data + width
        k = 1
        while j <= turn_off2 - num_data - (width - 1):
            # print('len(record[-1])', len(record[-1]))
            # print('j = ', j)
            # print('num_measure + k - 1 = ', num_measure + k - 1)
            record[-1][j] *= record[-1][num_measure + k - 1]
            record[-1][j - 1] *= record[-1][num_measure + k - 1]
            k += 1
            j += gap
        record[-1] = record[-1][0: num_measure]
        circuit_tmp.clear()
        # 初始化孤立数据比特
        j = turn_off1 - num_data + width
        while j <= turn_off2 - num_data - (width - 1):
            if xcut:
                s.reset(j)
            else:
                s.reset_x(j)
            j += gap
        # 更新字典
        k = turn_off1 + gap
        while k <= turn_off2 - gap:
            qdic[k - num_data] = [qdic[k - num_data][0], k - num_data, k - num_data - (width - 1),
                                  k - num_data + 1, k - num_data + width]
            qdic[k - num_data - (width - 1)].append(k - num_data - (width - 1))
            qdic[k - num_data - width].append(k - num_data - (width - 1))
            k += gap
        qdic[turn_off2 - num_data - (width - 1)].append(turn_off2 - num_data - (width - 1))
        qdic[turn_off2 - num_data - width].append(turn_off2 - num_data - (width - 1))
        # 更新电路
        circuit = runcirc(qdic)
        record = get_record(circuit)
        return circuit, qdic, record

    else:
        circuit1 = runcirc(qdic)
        _ = get_record(circuit1)
        stab_phase = 1
        if scale > 1:
            for k in range(0, scale - 1):
                stab_phase *= record[-1][turn_off2 - width * (scale - 1) + k - num_data]
                stab_phase *= record[-1][turn_off2 - (width - 1) * (scale - 1) + k * gap - num_data]
                stab_phase *= record[-1][turn_off2 + width * (scale - 1) - k - num_data]
                stab_phase *= record[-1][turn_off2 + (width - 1) * (scale - 1) - gap * k - num_data]
        else:
            stab_phase *= record[-1][turn_off2 - num_data]

        circuit2, qdic2, _ = cut(turn_off1, turn_off2, scale, xcut)
        l = np.array([])  # 用于记录需要被初始化的cut边界上的data qubit的下标
        for k in range(0, scale):
            l = np.append(l,
                          [turn_off2 - width * scale - num_data + 1 + k,
                           turn_off2 - (width - 1) * scale - num_data + width + k * gap,
                           turn_off2 + width * scale - num_data - k,
                           turn_off2 + (width - 1) * scale - num_data - (width - 1) - gap * k])
        L = [int(item) for item in l]
        if stab_phase == 1:
            for k in L:
                if xcut:
                    s.reset_x(k)
                else:
                    s.reset(k)
        else:
            for k in L:
                if xcut:
                    s.reset_x(k)
                    s.z(k)
                else:
                    s.reset(k)
                    s.x(k)
        return circuit2, qdic2, record


def cut_measure(scale: int, turn_off1: int, turn_off2: int, difficult=True, xcut=True):
    global qdic
    global record
    if difficult:
        # 更新字典
        k = turn_off1 + gap
        while k <= turn_off2 - gap:
            qdic[k - num_data] = [qdic[k - num_data][0]]
            qdic[k - num_data - (width - 1)].remove(k - num_data - (width - 1))
            qdic[k - num_data - width].remove(k - num_data - (width - 1))
            k += gap
        qdic[turn_off2 - num_data - (width - 1)].remove(turn_off2 - num_data - (width - 1))
        qdic[turn_off2 - num_data - width].remove(turn_off2 - num_data - (width - 1))
        # 更新电路
        circuit = runcirc(qdic)
        circuit_tmp = circuit.copy()
        # error track
        j = turn_off1 - num_data + width
        while j <= turn_off2 - num_data - (width - 1):
            if xcut:
                circuit_tmp.append("M", j)
            else:
                circuit_tmp.append("MX", j)
            j += gap
        record = get_record(circuit_tmp)
        j = turn_off1 - num_data + width
        k = 1
        while j <= turn_off2 - num_data - (width - 1):
            record[-1][j] *= record[-1][num_measure + k - 1]
            record[-1][j - 1] *= record[-1][num_measure + k - 1]
            k += 1
            j += gap
        record[-1] = record[-1][0: num_measure]
        circuit_tmp.clear()
        # 初始化孤立数据比特
        j = turn_off1 - num_data + width
        while j <= turn_off2 - num_data - (width - 1):
            if xcut:
                s.reset(j)
            else:
                s.reset_x(j)
            j += gap

        # 更新字典
        i = turn_off1
        while i <= turn_off2:
            qdic[i - num_data] = [qdic[i - num_data][0], i - num_data, i - num_data - (width - 1),
                                  i - num_data + 1, i - num_data + width]
            qdic[i - num_data + (width - 1)].append(i - num_data + width)
            qdic[i - num_data + width].append(i - num_data + width)
            i += gap
        # 更新电路
        circuit = runcirc(qdic)
        record = get_record(circuit)

        return circuit, qdic, record

    else:
        qdic[turn_off1 - num_data] = [qdic[turn_off1 - num_data][0], turn_off1 - num_data,
                                      turn_off1 - num_data - (width - 1),
                                      turn_off1 - num_data + 1,
                                      turn_off1 - num_data + width]
        qdic[turn_off2 - num_data] = [qdic[turn_off2 - num_data][0],
                                      turn_off2 - num_data, turn_off2 - num_data - (width - 1),
                                      turn_off2 - num_data + 1,
                                      turn_off2 - num_data + width]
        circuit = runcirc(qdic)
        record = get_record(circuit)
        return circuit, qdic, record


def qmove(scale: int, turn_off_1: int, turn_off_2: int, turn_to_2: int,
          X_cut=True):
    global qdic
    global record
    global byproduct_err

    m = min(turn_to_2, turn_off_2)
    M = max(turn_off_2, turn_to_2)

    # 更新字典
    if m == turn_off_2:
        i = m + gap
        while i <= M:
            qdic[i - num_data] = [qdic[i - num_data][0]]
            qdic[i - num_data - (width - 1)].remove(i - num_data - (width - 1))
            qdic[i - num_data - width].remove(i - num_data - (width - 1))
            i += gap
    else:
        i = M - gap
        while i >= m:
            qdic[i - num_data] = [qdic[i - num_data][0]]
            qdic[i - num_data + (width - 1)].remove(i - num_data + width)
            qdic[i - num_data + width].remove(i - num_data + width)
            i -= gap
    circuit = runcirc(qdic)
    circuit_tmp = circuit.copy()

    # 更新电路
    if not X_cut:

        if m == turn_off_2:  # 从上向下移动
            i = m + gap
            while i <= M:
                circuit_tmp.append("MX", i - num_data - (width - 1))
                i += gap
        else:  # 从下向上移动
            i = M - gap
            while i >= m:
                circuit_tmp.append("MX", i - num_data + width)
                i -= gap
    else:
        if m == turn_off_2:  # 从上向下移动
            i = m + gap
            while i <= M:
                circuit_tmp.append("M", i - num_data - (width - 1))
                i += gap
        else:  # 从下向上移动
            i = M - gap
            while i >= m:
                circuit_tmp.append("M", i - num_data + width)
                i -= gap
    record = get_record(circuit_tmp)

    if m == turn_off_2:  # 从上向下移动
        i = m + gap
        k = 1
        while i <= M:
            # print('len(record[-1])', len(record[-1]))
            # print('i - num_data - (width - 1)', i - num_data - (width - 1))
            # print('num_measure + k - 1', num_measure + k - 1)
            record[-1][i - num_data - (width - 1)] *= record[-1][num_measure + k - 1]
            record[-1][i - num_data - (width - 1) - 1] *= record[-1][num_measure + k - 1]
            i += gap
            k += 1
    else:  # 从下向上移动
        i = M - gap
        k = 1
        while i >= m:
            record[-1][i - num_data + width] *= record[-1][num_measure + k - 1]
            record[-1][i - num_data + width - 1] *= record[-1][num_measure + k - 1]
            i -= gap
            k += 1

    phase2 = 1
    n = int((M - m) / gap)
    for i in record[-2][len(record[-2]) - 1: len(record[-2]) - 1 - n:-1]:  # 从后往前取n个
        phase2 *= i
    record[-1] = record[-1][0: num_measure]
    circuit_tmp.clear()

    # 更新字典
    if m == turn_off_2:
        i = m
        while i <= M - gap:
            qdic[i - num_data] = [qdic[i - num_data][0], i - num_data, i - num_data - (width - 1),
                                  i - num_data + 1, i - num_data + width]
            qdic[i - num_data + (width - 1)].append(i - num_data + width)
            qdic[i - num_data + width].append(i - num_data + width)
            i += gap
    else:
        i = M
        while i >= m + gap:
            qdic[i - num_data] = [qdic[i - num_data][0], i - num_data, i - num_data - (width - 1),
                                  i - num_data + 1, i - num_data + width]
            qdic[i - num_data - (width - 1)].append(i - num_data - (width - 1))
            qdic[i - num_data - width].append(i - num_data - (width - 1))
            i -= gap

    # 更新电路
    circuit = runcirc(qdic)
    record = get_record(circuit)

    # Byproduct operators

    phase1 = 1
    i = m + gap
    while i <= M:
        phase1 *= record[-2][i - num_data]
        phase1 *= record[-1][i - gap - num_data]
        i += gap

    if not X_cut:
        if phase2 == 1:
            pass
        else:
            byproduct_err.append([turn_off_1 - num_data + width, 1, len(record) - 2])
        if phase1 == 1:
            pass
        else:
            byproduct_err.append([turn_off_2 - num_data - (width - 1), 0, len(record) - 1])

    else:
        if phase2 == 1:
            pass
        else:
            byproduct_err.append([turn_off_1 - num_data + width, 0, len(record) - 2])
        if phase1 == 1:
            pass
        else:
            byproduct_err.append([turn_off_2 - num_data - (width - 1), 1, len(record) - 1])

    return circuit, qdic


def qbraid_subx(scale: int, z1: int, z2: int, x2: int,
                x1: int, X_L1=True, X_L2=True, Z_L1=False, Z_L2=False):  # 输入时假设需要被编织的两个cut中心索引为z1, x2
    """因为此时的图已经是有两个洞的图，洞中的孤立数据比特已在相应基下测量并纠正过，
    因此在计算braid过程中X_L or Z_L 的移动产生的Z or X错误时，
    原始洞中的孤立比特测量结果不用计入在内，因为它在cut函数里已被测量过，
    并经过纠错后已成为相应可观测量的+1特征态 """
    global qdic
    global record
    global byproduct_err
    phasez1 = 1
    phasez2 = 1
    distance = int((max(z1, x2) - min(z1, x2)) / width)
    if Z_L1:
        for j in range(0, scale):
            i = x2 - width * distance - width * (scale - 1) - gap * scale + j
            while i <= x2 + (width - 1) * distance + (width - 1) * (scale - 1) + j:
                phasez1 *= record[-1][i - num_data]
                i += gap
            i = x2 + (width - 1) * distance + (width - 1) * (scale - 1) + scale - j * gap
            while i <= x2 + width * distance + width * (scale - 1) - j * gap:
                phasez1 *= record[-1][i - num_data]
                i += 1
            i = x2 + width * distance + width * (scale - 1) - gap * scale - j
            while i >= x2 - (width - 1) * distance - (width - 1) * (scale - 1) - j:
                phasez1 *= record[-1][i - num_data]
                i -= gap
        else:
            pass

    # 更新字典
    # 挖去一部分
    label = np.array([])  # 记录的是包含于cut里面的（除最外圈的）measure qubit的index
    isolate = []  # 记录的是包含于cut里面的（除最外圈的）data （to be applied turn_off function）
    isolate0 = []  # 记录的是包含于cut里面的最外圈的measure qubit的index
    for j in range(1, scale - 1):
        i = x2 - width * distance - width * (scale - 2) - gap * scale + j
        while i <= x2 + (width - 1) * distance + (width - 1) * (scale - 2) + j:
            label = np.append(label, [i])
            i += gap
        i = x2 + (width - 1) * distance + (width - 1) * (scale - 2) + scale - j * gap
        while i <= x2 + width * distance + width * (scale - 2) - j * gap:
            label = np.append(label, [i])
            i += 1
        i = x2 + width * distance + width * (scale - 2) - gap * scale - j
        while i >= x2 - (width - 1) * distance - (width - 2) * (scale - 1) - j:
            label = np.append(label, [i])
            i -= gap

    for j in range(0, scale):
        i = x2 - width * distance - width * (scale - 1) - gap * scale + j
        while i <= x2 + (width - 1) * distance + (width - 1) * (scale - 1) + j:
            isolate0.append(i)
            i += gap
        i = x2 + (width - 1) * distance + (width - 1) * (scale - 1) + scale - j * gap
        while i <= x2 + width * distance + width * (scale - 1) - j * gap:
            isolate0.append(i)
            i += 1
        i = x2 + width * distance + width * (scale - 1) - gap * scale - j
        while i >= x2 - (width - 1) * distance - (width - 1) * (scale - 1) - j:
            isolate0.append(i)
            i -= gap

    label = [int(item) for item in label]
    for k in isolate0:
        if k in label:
            isolate0.remove(k)
        else:
            pass

    for j in list(label):
        for k in qdic[j - num_data][1:]:
            isolate.append(k)
    for r in isolate0:
        qdic[r - num_data] = [qdic[r - num_data][0]]
    qdic = turn_off(isolate)

    circuit = runcirc(qdic)
    circuit_tmp = circuit.copy()
    # 获取孤立比特X基测量结果

    measure_isolate = []

    for j in [0, scale - 1]:
        i = x2 - width * distance - width * (scale - 1) - gap * scale + j
        while i <= x2 + (width - 1) * distance + (width - 1) * (scale - 1) + j:
            measure_isolate.append(i - num_data - (width - 1))
            i += gap
        i = x2 + (width - 1) * distance + (width - 1) * (scale - 1) + scale - j * gap
        while i <= x2 + width * distance + width * (scale - 1) - j * gap:
            measure_isolate.append(i - num_data)
            i += 1
        i = x2 + width * distance + width * (scale - 1) - gap * scale - j
        while i >= x2 - (width - 1) * distance - (width - 1) * (scale - 1) - j:
            measure_isolate.append(i - num_data + (width - 1))
            i -= gap

    for i in measure_isolate:
        circuit_tmp.append("MX", i)
    record = get_record(circuit_tmp)
    phasex1 = 1
    # 修正 qdic，补偿为stabilizer形式
    k = 1
    j = 0
    i = x2 - width * distance - width * (scale - 1) - gap * scale + j
    while i <= x2 + (width - 1) * distance + (width - 1) * (scale - 1) + j:
        record[-1][i - num_data - width] *= record[-1][num_measure + k - 1]
        i += gap
        k += 1
    i = x2 + (width - 1) * distance + (width - 1) * (scale - 1) + scale - j * gap
    while i <= x2 + width * distance + width * (scale - 1) - j * gap:
        record[-1][i - num_data + (width - 1)] *= record[-1][num_measure + k - 1]
        i += 1
        k += 1
    i = x2 + width * distance + width * (scale - 1) - gap * scale - j
    while i >= x2 - (width - 1) * distance - (width - 1) * (scale - 1) - j:
        record[-1][i - num_data + width] *= record[-1][num_measure + k - 1]
        i -= gap

    j = scale - 1
    i = x2 - width * distance - width * (scale - 1) - gap * scale + j
    while i <= x2 + (width - 1) * distance + (width - 1) * (scale - 1) + j:
        record[-1][i - num_data - (width - 1)] *= record[-1][num_measure + k - 1]
        phasex1 *= record[-1][num_measure + k - 1]
        i += gap
        k += 1
    i = x2 + (width - 1) * distance + (width - 1) * (scale - 1) + scale - j * gap
    while i <= x2 + width * distance + width * (scale - 1) - j * gap:
        record[-1][i - num_data - width] *= record[-1][num_measure + k - 1]
        phasex1 *= record[-1][num_measure + k - 1]
        i += 1
        k += 1
    i = x2 + width * distance + width * (scale - 1) - gap * scale - j
    while i >= x2 - (width - 1) * distance - (width - 1) * (scale - 1) - j:
        record[-1][i - num_data + (width - 1)] *= record[-1][num_measure + k - 1]
        phasex1 *= record[-1][num_measure + k - 1]
        i -= gap
    record[-1] = record[-1][0: num_measure]
    circuit_tmp.clear()

    # 填充
    label_on = np.array([])  # 记录的是包含于cut里面的(除最外圈的)measure qubit的index
    isolate_on = []  # 记录的是包含于cut里面的data qubit的index
    isolate0 = []  # 记录的是包含于cut里面的最外圈的measure qubit的index
    for j in range(1, scale - 1):
        i = x2 - width * distance - width * (scale - 2) + j
        while i <= x2 + (width - 1) * distance + (width - 1) * (scale - 2) + j:
            label_on = np.append(label_on, [i])
            i += gap
        i = x2 + (width - 1) * distance + (width - 1) * (scale - 2) + scale - j * gap
        while i <= x2 + width * distance + width * (scale - 2) - j * gap:
            label_on = np.append(label_on, [i])
            i += 1
        i = x2 + width * distance + width * (scale - 2) - gap * scale - j
        while i >= x2 - (width - 1) * distance - (width - 1) * (scale - 2) + gap * scale - j:
            label_on = np.append(label_on, [i])
            i -= gap

    for j in range(0, scale):
        i = x2 - width * distance - width * (scale - 1) + j
        while i <= x2 + (width - 1) * distance + (width - 1) * (scale - 1) + j:
            isolate0.append(i)
            i += gap
        i = x2 + (width - 1) * distance + (width - 1) * (scale - 1) + scale - j * gap
        while i <= x2 + width * distance + width * (scale - 1) - j * gap:
            isolate0.append(i)
            i += 1
        i = x2 + width * distance + width * (scale - 1) - gap * scale - j
        while i >= x2 - (width - 1) * distance - (width - 1) * (scale - 1) + gap * scale - j:
            isolate0.append(i)
            i -= gap
    label_on = [int(item) for item in label_on]
    for k in isolate0:
        if k in label_on:
            isolate0.remove(k)
        else:
            pass

    for j in list(label_on):
        for k in qdic[j - num_data][1:]:
            isolate_on.append(k)
    for i in isolate0:
        qdic[i - num_data] = [qdic[i - num_data][0], i - num_data, i - num_data - (width - 1), i - num_data + 1,
                              i - num_data + width]
    qdic = turn_on(isolate_on)
    circuit = runcirc(qdic)
    record = get_record(circuit)
    if Z_L1:
        for j in range(0, scale):
            i = x2 - width * distance - width * (scale - 1) + j
            while i <= x2 + (width - 1) * distance + (width - 1) * (scale - 1) + j:
                phasez1 *= record[-1][i - num_data]
                i += gap
            i = x2 + (width - 1) * distance + (width - 1) * (scale - 1) + scale - j * gap
            while i <= x2 + width * distance + width * (scale - 1) - j * gap:
                phasez1 *= record[-1][i - num_data]
                i += 1
            i = x2 + width * distance + width * (scale - 1) - gap * scale - j
            while i >= x2 - (width - 1) * distance - (width - 1) * (scale - 1) + gap * scale - j:
                phasez1 *= record[-1][i - num_data]
                i -= gap
            i = x2 - (width - 1) * distance - (width - 1) * (scale - 1) - scale - j * gap
            while i >= x2 - width * distance - width * (scale - 1) - j * gap:
                phasez1 *= record[-1][i - num_data]
                i -= 1

        else:
            pass

    # 挖去剩下的
    label = np.array([])   # 记录的是包含于cut里面的(除最外圈的)measure qubit的index
    isolate = []  # 记录的是包含于cut里面的data qubit的index
    isolate0 = []  # 记录的是包含于cut里面的最外圈的measure qubit的index
    for j in range(1, scale - 1):
        i = x2 - (width - 1) * distance - (width - 1) * (scale - 2) - scale - j * gap
        while i >= x2 - width * distance - width * (scale - 2) - j * gap:
            label = np.append(label, [i])
            i -= 1
    for j in range(0, scale):
        i = x2 - (width - 1) * distance - (width - 1) * (scale - 2) - scale - j * gap
        while i >= x2 - width * distance - width * (scale - 2) - j * gap:
            isolate0.append(i)
            i -= 1
    label = [int(item) for item in label]
    for k in isolate0:
        if k in label:
            isolate0.remove(k)
        else:
            pass

    for j in list(label):
        for k in qdic[j - num_data][1:]:
            isolate.append(k)
    for r in isolate0:
        qdic[r - num_data] = [qdic[r - num_data][0]]
    qdic = turn_off(isolate)

    circuit = runcirc(qdic)
    circuit_tmp = circuit.copy()
    measure_isolate = []

    for j in [0, scale - 1]:
        i = x2 - (width - 1) * distance - (width - 1) * (scale - 1) - scale - j * gap
        while i <= x2 - width * distance - width * (scale - 1) - j * gap:
            measure_isolate.append(i - num_data + 1)
            i += gap

    for i in measure_isolate:
        circuit_tmp.append("MX", i)
    record = get_record(circuit_tmp)

    k = 1
    j = 0
    i = x2 - (width - 1) * distance - (width - 1) * (scale - 1) - scale - j * gap
    while i <= x2 - width * distance - width * (scale - 1) - j * gap:
        record[-1][i - num_data - (width - 1)] *= record[-1][num_measure + k - 1]
        i += gap
        k += 1
    j = scale - 1
    while i <= x2 - width * distance - width * (scale - 1) - j * gap:
        record[-1][i - num_data + width] *= record[-1][num_measure + k - 1]
        phasex1 *= record[-1][num_measure + k - 1]
        i += gap
        k += 1

    circuit_tmp.clear()
    record[-1] = record[-1][0: num_measure]

    # 填充
    label_on = np.array([])  # 记录的是包含于cut里面的measure qubit的index
    isolate_on = []  # 记录的是包含于cut里面的data qubit的index
    isolate0 = []  # 记录的是包含于cut里面的最外圈的measure qubit的index
    for j in range(1, scale - 1):
        i = x2 - (width - 1) * distance - (width - 1) * (scale - 2) - j * gap
        while i >= x2 - width * distance - width * (scale - 2) + scale - j * gap:
            label_on = np.append(label_on, [i])
            i -= 1

    for j in range(0, scale):
        i = x2 - (width - 1) * distance - (width - 1) * (scale - 1) - j * gap
        while i >= x2 - width * distance - width * (scale - 1) + scale - j * gap:
            isolate0.append(i)
            i -= 1
    label_on = [int(item) for item in label_on]
    for k in isolate0:
        if k in label_on:
            isolate0.remove(k)
        else:
            pass
    for j in list(label_on):
        for k in qdic[j - num_data][1:]:
            isolate_on.append(k)
    for i in isolate0:
        qdic[i - num_data] = [qdic[i - num_data][0], i - num_data, i - num_data - (width - 1), i - num_data + 1,
                              i - num_data + width]
    qdic = turn_on(isolate_on)

    # 更新电路
    circuit = runcirc(qdic)
    record = get_record(circuit)

    if Z_L1:
        for j in range(0, scale):
            i = x2 - (width - 1) * distance - (width - 1) * (scale - 1) - j * gap
            while i <= x2 - width * distance - width * (scale - 1) + scale - j * gap:
                phasez1 *= record[-1][i - num_data]
                i += gap
    else:
        pass

    phasex2 = 1
    # byproduct operator

    label = np.array([])  # 记录的是包含于X_L构成的LOOP内部且在上面的Xcut之外的X stabilizer对应的measure qubit的index
    for k in range(scale + 1, distance - (scale - 1)):
        j = 0
        while j < k:
            label = np.append(label, [x2 - width * k + j, x2 - (width - 1) * k + gap * j,
                                      x2 + width * k - j, x2 + (width - 1) * k - gap * j])
            j += 1
    label = [int(item) for item in label]
    for k in label:
        phasex2 *= record[-1][k]

    if X_L1:
        if phasex1 == 1:
            pass
        else:
            byproduct_err.append([z1 - num_data + width, 1, len(record) - 3])
        if phasex2 == 1:
            pass
        else:
            byproduct_err.append([x2 - num_data - (width - 1), 1, len(record) - 1])
    else:
        pass

    if Z_L2:
        if phasez1 == 1:
            pass
        else:
            byproduct_err.append([z1 - num_data + width, 0, len(record) - 2])
        if phasez2 == 1:
            pass
        else:
            byproduct_err.append([x2 + gap - num_data - (width - 1), 0, len(record) - 1])

    return circuit, qdic


def Hadamard(scale: int, turn_off1: int, turn_off2: int, x_cut=True):  # 输入时按照turn_off1>turn_off2计算
    global circuit
    global qdic
    global record
    # global byproduct_err
    lenth = turn_off1 - turn_off2 + 2 * scale * gap
    p = int(lenth / 2)
    # 将要处理的logical_qubit对应的cut分离出来，通过在这个cut外围用turnoff手段挖loop，将cut隔离在一个子块里
    # 更新qdic
    isolate = []
    i = turn_off1 - scale * gap - p
    while i <= turn_off1 - scale * gap + lenth - p - 1:
        isolate.append(i + 1)
        i += 1

    i = turn_off1 - scale * gap + lenth - p
    while i <= turn_off1 - scale * gap + lenth - p + (lenth - 1) * gap:
        isolate.append(i - width)
        i += gap

    i = turn_off1 - scale * gap + lenth - p + lenth * gap
    while i >= turn_off1 - scale * gap + lenth - p + lenth * gap - lenth - 1:
        isolate.append(i)
        i -= 1

    i = turn_off1 - scale * gap + lenth - p + lenth * gap - lenth
    while i >= turn_off1 - scale * gap - p:
        isolate.append(i - (width - 1))
        i -= gap
    qdic = turn_off(isolate)
    circuit = runcirc(qdic)
    circuit_tmp = circuit.copy()
    for k in isolate:
        if not x_cut:
            circuit_tmp.append("M", k)
        else:
            circuit_tmp.append("MX", k)
    record = get_record(circuit_tmp)
    k = 0
    i = turn_off1 - scale * gap - p
    while i <= turn_off1 - scale * gap + lenth - p - 1:
        record[-1][i + width] *= record[-1][num_measure + k]
        record[-1][i - (width - 1)] *= record[-1][num_measure + k]
        i += 1
        k += 1

    i = turn_off1 - scale * gap + lenth - p
    while i <= turn_off1 - scale * gap + lenth - p + (lenth - 1) * gap:
        record[-1][i + width] *= record[-1][num_measure + k]
        record[-1][i + (width - 1)] *= record[-1][num_measure + k]
        i += gap
        k += 1

    i = turn_off1 - scale * gap + lenth - p + lenth * gap
    while i >= turn_off1 - scale * gap + lenth - p + lenth * gap - lenth - 1:
        record[-1][i - width] *= record[-1][num_measure + k]
        record[-1][i + (width - 1)] *= record[-1][num_measure + k]
        i -= 1
        k += 1

    i = turn_off1 - scale * gap + lenth - p + lenth * gap - lenth
    while i >= turn_off1 - scale * gap - p:
        record[-1][i - width] *= record[-1][num_measure + k]
        record[-1][i - (width - 1)] *= record[-1][num_measure + k]
        i -= gap
        k += 1

    record[-1] = record[-1][0: num_measure]

    # 形变下面的cut_operator
    label2 = np.array([])
    for i in range(0, scale):  # (cut内部的measure qubit的index，存储在label2中)
        j = 0
        while j < i:
            label2 = np.append(label2, [
                turn_off2 - width * i + j, turn_off2 - (width - 1) * i + gap * j,
                turn_off2 + width * i - j, turn_off2 + (width - 1) * i - gap * j])
    label2 = [int(item) for item in label2]
    i2 = int(turn_off2 - gap + width + lenth - p - 1)
    i1 = int(turn_off2 - gap + (width - 1) - p + 1)
    index_z = []
    for r in range(0, scale + 2):
        for i in range(i1 + gap * r, i2 + gap * r + 1):
            index_z.append(i)
    for k in list(label2):
        index_z.remove(k)
    # 形变需要乘的stabilizer的测量结果的乘积
    stabilizer_product = 1
    for i in index_z:
        stabilizer_product *= record[-1][i]
        # for j in qdic[i - num_data][1:]:
        #     circuit.append("Z", j)

    # 截取两洞之间没有cut的子surface code
    i1 = turn_off1 - gap - num_data - (width - 1) - (p - 1)
    i2 = turn_off1 - gap - num_data - (width - 1) + (lenth - p - 1)
    index = []  # 用于记录需要挖去的data qubit的下标
    for r in range(0, scale + 1):
        for i in range(i1 + gap * r, i2 + gap * r + 1):
            index.append(i)

    i5 = turn_off1 - gap - num_data - (p - 1)
    i6 = turn_off1 - gap - num_data + 1 + (lenth - p - 1)
    for r in range(0, scale + 1):
        for i in range(i5 + gap * r, i6 + gap * r + 1):
            index.append(i)

    i3 = turn_off2 - num_data - (width - 1) - (p - 1)
    i4 = turn_off2 - num_data - (width - 1) + (lenth - p - 1)
    for r in range(0, scale + 1):
        for i in range(i3 + gap * r, i4 + gap * r + 1):
            index.append(i)

    i7 = turn_off2 - gap - num_data - (p - 1)
    i8 = turn_off2 - gap - num_data + 1 + (lenth - p - 1)
    for r in range(0, scale + 1):
        for i in range(i7 + gap * r, i8 + gap * r + 1):
            index.append(i)

    small_lenth = turn_off1 - turn_off2 - 2
    q = int(small_lenth / 2)
    i9 = turn_off1 + 2 * gap - num_data - (p - 1)
    i10 = turn_off1 + 2 * gap - num_data - q
    for r in range(0, small_lenth - 1):
        for i in range(i9 + gap * r, i10 + gap * r + 1):
            index.append(i)

    i11 = turn_off1 + gap - num_data + width - (p - 1)
    i12 = turn_off1 + gap - num_data + width - q
    for r in range(0, small_lenth - 1):
        for i in range(i11 + gap * r, i12 + gap * r + 1):
            index.append(i)

    i13 = turn_off1 + 2 * gap - num_data + 1 + (lenth - p - 1)
    i14 = turn_off1 + 2 * gap - num_data + 1 + (small_lenth - q) + 1
    for r in range(0, small_lenth - 1):
        for i in range(i14 + gap * r, i13 + gap * r + 1):
            index.append(i)

    i15 = turn_off1 + gap - num_data + width + (lenth - p - 1)
    i16 = turn_off1 + gap - num_data + width + (small_lenth - q) + 1
    for r in range(0, small_lenth - 1):
        for i in range(i16 + gap * r, i15 + gap * r + 1):
            index.append(i)
    # ------------------------------------------------------------------------------
    qdic = turn_off(index)
    # ------------------------------------------------------------------------------
    circuit = runcirc(qdic)
    top_bottom_isolate = []
    left_right_isolate = []
    for i in range(turn_off1 - num_data + width - (q - 1), turn_off1 - num_data + width + small_lenth - q + 1):
        top_bottom_isolate.append(i)
    for i in range(turn_off2 - num_data + width - (q - 1), turn_off2 - num_data + width + small_lenth - q + 1):
        top_bottom_isolate.append(i)
    k1 = turn_off1 - num_data + width - q + gap
    while k1 <= turn_off1 - num_data + width - q + small_lenth * gap:
        left_right_isolate.append(k1)
        k1 += gap
    k2 = turn_off1 - num_data + width + small_lenth - q + 1 + gap
    while k2 <= turn_off1 - num_data + width + small_lenth - q + 1 + small_lenth * gap:
        left_right_isolate.append(k2)
        k2 += gap
    circuit_tmp = circuit.copy()

    for k in top_bottom_isolate:
        if not x_cut:
            circuit_tmp.append("MX", k)
        else:
            circuit_tmp.append("M", k)
    for k in left_right_isolate:
        if not x_cut:
            circuit_tmp.append("M", k)
        else:
            circuit_tmp.append("MX", k)
    record = get_record(circuit_tmp)

    k = 0
    for i in range(turn_off1 - num_data + width - (q - 1), turn_off1 - num_data + width + small_lenth - q + 1):
        record[-1][i + (width - 1)] *= record[-1][num_measure + k]
        k += 1
    for i in range(turn_off2 - num_data + width - (q - 1), turn_off2 - num_data + width + small_lenth - q + 1):
        record[-1][i - width] *= record[-1][num_measure + k]
        k += 1
    k1 = turn_off1 - num_data + width - q + gap
    while k1 <= turn_off1 - num_data + width - q + small_lenth * gap:
        record[-1][i] *= record[-1][num_measure + k]
        k1 += gap
        k += 1
    k2 = turn_off1 - num_data + width + small_lenth - q + 1 + gap
    while k2 <= turn_off1 - num_data + width + small_lenth - q + 1 + small_lenth * gap:
        record[-1][i + 1] *= record[-1][num_measure + k]
        k2 += gap
        k += 1
    record[-1] = record[-1][0: num_measure]

    #  对挖出来的sub surface code中的每一个数据比特作用H门
    for r in range(0, small_lenth + 1):
        for i in range(turn_off1 + gap - num_data - q + 1 + r * gap,
                       turn_off1 + gap - num_data + 1 + (small_lenth - q) + 1 + r * gap):
            circuit.append("H", i)
        for i in range(turn_off1 + gap - num_data + width - q + 1 + r * gap,
                       turn_off1 + gap - num_data + width + (small_lenth - q) + 1 + r * gap):
            circuit.append("H", i)

    #  对挖出来的sub surface code中的每一个数据比特作用SWAP门
    for r in range(0, small_lenth + 1):
        for i in range(turn_off1 + gap - num_data - q + 1 + r * gap,
                       turn_off1 + gap - num_data + 1 + (small_lenth - q) + 1 + r * gap):
            circuit.append("SWAP", [i + num_data - width, i])
        for i in range(turn_off1 + gap - num_data + width - q + 1 + r * gap,
                       turn_off1 + gap - num_data + width + (small_lenth - q) + 1 + r * gap):
            circuit.append("SWAP", [i + num_data - width, i])

    for r in range(0, small_lenth + 1):
        for i in range(turn_off1 + gap - q + 1 + r * gap,
                       turn_off1 + gap + (small_lenth - q) + 1 + r * gap):
            circuit.append("SWAP", [i + num_data, i])
        for i in range(turn_off1 + gap + width - 1 - q + 1 + r * gap,
                       turn_off1 + gap + width + (small_lenth - q) + 1 + r * gap):
            circuit.append("SWAP", [i + num_data, i])

    #  turn on至大的patch
    minus = []
    pluse = []
    for i in range(turn_off1 - num_data + width - (q - 1), turn_off1 - num_data + width + small_lenth - q + 1):
        pluse.append(i)
    for i in range(turn_off2 - num_data + width - (q - 1), turn_off2 - num_data + width + small_lenth - q + 1):
        minus.append(i)
    k1 = turn_off1 - num_data + width - q + gap
    while k1 <= turn_off1 - num_data + width - q + small_lenth * gap:
        pluse.append(i)
        k1 += gap
    k2 = turn_off1 - num_data + width + small_lenth - q + 1 + gap
    while k2 <= turn_off1 - num_data + width + small_lenth - q + 1 + small_lenth * gap:
        minus.append(i)
        k2 += gap

    for r in minus:
        index.remove(r)
    for r in pluse:
        index.append(r)
    qdic = turn_on(index)
